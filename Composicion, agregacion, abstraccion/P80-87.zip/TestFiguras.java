
public class TestFiguras {

	public static void main(String[] args) {
		Punto p = new Punto(0,0);
		Circulo c = new Circulo(p, 10);
		Cilindro cd = new Cilindro(c, 50);
		
		p.trasladar(1, 1);
		c.trasladar(-1, -1);
		c.perimetro();
		c.area();
		cd.volumen();
		System.out.println(cd);
	}

}
