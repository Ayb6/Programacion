
public class testCielo {

    public static void main(String[] args) {
        Cielo cielo = new Cielo(18, 60);
        cielo.ponerEstrellas(150);
        System.out.println(cielo);
    }
}
