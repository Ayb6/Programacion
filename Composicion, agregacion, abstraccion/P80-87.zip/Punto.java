
public class Punto {
	private int x;
	private int y;

	public Punto(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public void trasladar(int a, int b) {
		x += a;
		y += b;
	}

	@Override
	public String toString() {
		return ("(" + x + "," + y + ")");
	}
}
