
public class Cilindro {

	private Circulo base;
	private double altura;
	
	public Cilindro(Circulo base, double altura) {
		this.base = base;
		this.altura = altura;
	}
	
	public double volumen() {
		return (base.area()*altura);
	}
	
	@Override
	public String toString() {
		return ("Base: " + base.toString() + ", Altura: " + altura);
	}
}
