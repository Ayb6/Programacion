
public class Bala {

    private final int calibre; // mm
    private final int longitud; //mm

    public Bala() {
        calibre = 9;
        longitud = 40;
    }

    public Bala(int calibre, int longitud) {
        this.calibre = calibre;
        this.longitud = longitud;
    }

    @Override
    public String toString() {
        return ("Bala de calibre " + calibre + "mm y longitud " + longitud + "mm");
    }
}
