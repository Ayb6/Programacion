
public class Revolver {

    private String marca;
    private String modelo;
    private Bala[] tambor;
    private int martillo;

    public Revolver(String marca, String modelo, int tamTambor) {
        this.marca = marca;
        this.modelo = modelo;
        tambor = new Bala[tamTambor];
        martillo = 0;

        //Llenar tambor con balas de mismo calibre y longitud
        // Por ejemplo, de 9mm y 40mm, usando constructor sin args
        /*
        for(Bala b : tambor){
            b = new Bala();
        }
         */
        //Llenar tambor con balas de calibre aleatorio entre 5 y 20
        // y longitud aleatoria entre 20 y 70
        for (int i = 0; i < tambor.length; i++) {
            tambor[i] = new Bala(((int) (Math.random() * 16 + 5)), ((int) (Math.random() * 51 + 20)));
        }
    }

    public void disparar() {
        if (tambor[martillo] != null) {
            System.out.println(tambor[martillo]);
            tambor[martillo] = null;
        } else {
            System.out.println("No hay bala en ese hueco.");
        }
        martillo = (martillo + 1) % tambor.length;
    }

    private int numBalas() {
        int numBalas = 0;
        for (Bala b : tambor) {
            if (b != null) {
                numBalas++;
            }
        }
        return numBalas;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Marca: ").append(marca)
                .append("\nModelo: ").append(modelo)
                .append("\nTamaño tambor: ").append(tambor.length);
        if (numBalas() == 0) {
            sb.append("\nNo hay balas");
        } else {
            for (Bala b : tambor) {
                if (b != null) {
                    sb.append("\n").append(b.toString());
                }
            }
        }
        return sb.toString();
    }
}
