
public class testRevolver {

    public static void main(String[] args) {
        Revolver rev = new Revolver("Winchester", "1883", 6);
        System.out.println(rev);
        System.out.println();
        
        for (int i = 0; i < 25; i++) {
            rev.disparar();
        }
        
        System.out.println();
        System.out.println(rev);

    }
}
