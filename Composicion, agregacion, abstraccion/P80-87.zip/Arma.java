
public class Arma {

    private String nombre;
    private int resistencia;
    private int poder;
    private int nivel;

    public Arma(String nombre, int resistencia, int poder) {
        this.nombre = nombre;
        this.resistencia = resistencia;
        this.poder = poder;
        nivel = 1;
    }

    public void subirNivel() {
        resistencia += 2;
        poder += 1;
        nivel++;
    }
    
    public void mejorarArma(String nombre){
        if(nombre.equalsIgnoreCase(this.nombre)){
            subirNivel();
        }
    }
    
    public String getNombre(){
        return nombre;
    }

    public int getResistencia() {
        return resistencia;
    }

    public int getPoder() {
        return poder;
    }

    public void setResistencia(int resistencia) {
        this.resistencia = resistencia;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append(nombre)
                .append(" tiene ")
                .append(resistencia)
                .append(" resistencia y ")
                .append(poder).append(" poder.");

        return sb.toString();
    }
}
