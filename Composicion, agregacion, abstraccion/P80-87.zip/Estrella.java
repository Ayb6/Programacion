
public class Estrella {
    private int x;
    private int y;
    private char forma;
    
    public Estrella(int x, int y){
        this.x = x;
        this.y = y;
        
        if(Math.random()<1.0/4.0){
            forma = '*';
        }else{
            forma = '.';
        }
    }
    
    @Override
    public String toString(){
        return Character.toString(forma);
    }
}
