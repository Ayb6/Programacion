
public class Circulo {
	private double radio;
	private Punto centro;

	public Circulo(Punto centro, double radio) {
		this.radio = radio;
		this.centro = centro;
	}

	public double area() {
		return (Math.PI * radio * radio);
	}

	public double perimetro() {
		return (Math.PI * radio * 2);
	}

	public void trasladar(int a, int b) {
		centro.trasladar(a, b);
	}
	
	@Override
	public String toString() {
		return ("(Radio: " + radio + ", Centro: " + centro.toString() + ")");
	}
}
