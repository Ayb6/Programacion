
public class Cielo {

    private Estrella[][] cielo;

    public Cielo(int filas, int columnas) {
        cielo = new Estrella[filas][columnas];
    }

    public void ponerEstrellas(int numEstrellas) {
        if (numEstrellas < 0 || numEstrellas > (cielo.length * cielo[0].length)) {
            System.out.println("ERROR. Numero de estrellas invalido.");
            return;
        }
        int estrellasPuestas = 0;
        int filaAleatoria, columnaAleatoria;
        while (estrellasPuestas < numEstrellas) {
            filaAleatoria = (int) (Math.random() * cielo.length);
            columnaAleatoria = (int) (Math.random() * cielo[0].length);

            if (cielo[filaAleatoria][columnaAleatoria] == null) {
                cielo[filaAleatoria][columnaAleatoria] = new Estrella(filaAleatoria, columnaAleatoria);
                estrellasPuestas++;
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (Estrella[] fila : cielo) {
            for (Estrella estrella : fila) {
                if (estrella == null) {
                    sb.append(" ");
                } else {
                    sb.append(estrella.toString());
                }
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}
