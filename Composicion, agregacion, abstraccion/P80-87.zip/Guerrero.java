
public class Guerrero {

    private String nombre;
    private int saludMaxima;
    private int saludActual;
    private int ataque;
    private int escudo;
    private boolean muerto;
    private Arma arma;

    private int nivel;
    private int experienciaActual;
    private int siguienteNivel;

    public Guerrero(String nombre, int saludMaxima, int ataque, int escudo, Arma arma) {
        this.nombre = nombre;
        this.saludMaxima = saludMaxima;
        saludActual = saludMaxima;
        this.ataque = ataque;
        this.escudo = escudo;
        muerto = false;
        this.arma = arma;

        nivel = 1;
        experienciaActual = 0;
        actualizarSiguienteNivel();

    }

    public int atacar(Guerrero defensor) {
        if (muerto) {
            System.out.println("No puede atacar, atacante esta muerto.");
            return -1;
        } else if (defensor.muerto) {
            System.out.println("No puede atacar, defensor esta muerto.");
            return -1;
        } else {
            int fuerza = ataque;

            if (arma.getResistencia() > 0) {
                fuerza += arma.getPoder();
                arma.setResistencia(arma.getResistencia() - 1);
                defensor.recibirAtaque(fuerza);
                //Si ataca con arma, gana 3 exp
                ganarExperiencia(3);
            } else {
                defensor.recibirAtaque(fuerza);
                //Si ataca sin arma, gana 5 exp
                ganarExperiencia(5);
            }
            return fuerza;
        }
    }

    public void mejorarArma(String nombreArma) {
        if (nombreArma.equalsIgnoreCase(arma.getNombre())) {
            arma.subirNivel();
        }
    }

    private void recibirAtaque(int fuerza) {
        this.saludActual -= Math.max(0, (fuerza - escudo));
        if (saludActual <= 0) {
            muerto = true;
        }
    }

    private void actualizarSiguienteNivel() {
        siguienteNivel = (int) (Math.ceil(nivel * 11.5));
    }

    private void ganarExperiencia(int exp) {
        experienciaActual += exp;
        while (subir()) {
            subidaNivel();
        }
    }

    public boolean subir() {
        return experienciaActual >= siguienteNivel;
    }

    public void subidaNivel() {
        nivel++;
        experienciaActual -= siguienteNivel;
        actualizarSiguienteNivel();
        ataque += 1;
        escudo += 1;
        saludMaxima += 10;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        sb.append("Nombre: ").append(nombre)
                .append("\nSalud Maxima: ")
                .append(saludMaxima)
                .append("\nSalud Actual: ")
                .append(saludActual)
                .append("\nAtaque: ")
                .append(ataque)
                .append("\nEscudo: ")
                .append(escudo)
                .append("\nArma: ")
                .append(arma)
                .append("\nVivo: ")
                .append(!muerto);

        return sb.toString();
    }
}
