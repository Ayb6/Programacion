
public class Cancion extends Multimedia {
    private String artista;
    private String editor;
    private String genero;

    public Cancion(String artista, String editor, String genero, String titulo, String formato, int duracion) {
        super(titulo, formato, duracion);
        this.artista = artista;
        this.editor = editor;
        switch(genero){
            case "pop": case "flamenco": case "hiphop":
            case "R&B": case "reggaeton":
                this.genero = genero;
                break;
            default:
                this.genero = "rock";
        }
    }

    public String getArtista() {
        return artista;
    }

    public String getEditor() {
        return editor;
    }

    public String getGenero() {
        return genero;
    }
    
    @Override
    public String toString(){
        Multimedia esteM = (Multimedia)this;
        StringBuilder sb = new StringBuilder(esteM.toString());
        sb.append("\nArtista: ").append(artista)
                .append(" Editor: ").append(editor)
                .append(" Genero: ").append(genero);
        return sb.toString();
    }
}
