
public class Perro extends Mamifero {

    private String raza;
    private String nombre;
    private boolean mezcla;

    public Perro(int numPatas, int mediaDeVida, String raza, String nombre) {
        super(numPatas, mediaDeVida);
        this.raza = raza;
        this.nombre = nombre;
        mezcla = false;
    }

    @Override
    public String comunicarse() {
        return "Guau guau";
    }

    @Override
    public void dormir() {
        System.out.println("Suele dormir 18 horas.");
    }

    public void jugar() {
        System.out.println(nombre + " esta jugando");
    }

    public boolean isMezcla() {
        return mezcla;
    }

    public void setMezcla(boolean mezcla) {
        this.mezcla = mezcla;
    }

    @Override
    public String toString() {
        return "Perro llamado " + nombre + " de raza " + raza 
                + " con "+ super.getNumPatas() + " patas y " 
                + super.getMediaDeVida() + " media de vida.";
    }
}
