
import java.util.Objects;

public class Pelicula extends Multimedia {

    private String actorPrincipal;
    private String actrizPrincipal;

    public Pelicula(String titulo, String formato, int duracion, String actorPrincipal, String actrizPrincipal) {
        super(titulo, formato, duracion);
        this.actorPrincipal = actorPrincipal;
        this.actrizPrincipal = actrizPrincipal;
    }

    public String getActorPrincipal() {
        return actorPrincipal;
    }

    public String getActrizPrincipal() {
        return actrizPrincipal;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append("\nActor principal: ").append(actorPrincipal)
                .append("\nActriz principal: ").append(actrizPrincipal);
        return sb.toString();
    }

    public boolean equals(Pelicula otroP) {
        return actorPrincipal.equals(otroP.actorPrincipal)
                && actrizPrincipal.equals(otroP.actrizPrincipal)
                && super.equals(otroP);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Pelicula)) {
            return false;
        }
        return this.equals((Pelicula) o);
    }

    @Override
    public int hashCode() {
        Multimedia thisM = (Multimedia) this;
        int hash = thisM.hashCode();
        hash = 11 * hash + Objects.hashCode(this.actorPrincipal);
        hash = 11 * hash + Objects.hashCode(this.actrizPrincipal);
        return hash;
    }

}
