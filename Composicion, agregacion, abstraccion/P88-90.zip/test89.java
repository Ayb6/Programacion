

public class test89 {

    public static void main(String[] args) {
        Perro p1 = new Perro(4, 12, "beagle", "Toby");
        Gato g1 = new Gato(4, 9);
        
        System.out.println(p1);
        System.out.println(g1);

    }
}
