
public class Mamifero {

    private int numPatas;
    private int mediaDeVida;

    public Mamifero(int numPatas, int mediaDeVida) {
        this.numPatas = numPatas;
        this.mediaDeVida = mediaDeVida;
    }

    public String comunicarse() {
        return "";
    }

    public void dormir() {
        System.out.println("Suele dormir 8 horas.");
    }

    public int getNumPatas() {
        return numPatas;
    }

    public int getMediaDeVida() {
        return mediaDeVida;
    }

    @Override
    public String toString() {
        return "Mamifero con " + numPatas + " patas y " + mediaDeVida + " media de vida.";
    }
}
