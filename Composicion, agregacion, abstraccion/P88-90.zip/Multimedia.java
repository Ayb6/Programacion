
import java.util.Objects;


public class Multimedia {

    private String titulo;
    private String formato;
    private int duracion; //segundos

    public Multimedia(String titulo, String formato, int duracion) {
        this.titulo = titulo;
        this.duracion = duracion;
        switch (formato) {
            case "wav":
            case "aac":
            case "mp4":
            case "mkv":
            case "mov":
            case "flv":
                this.formato = formato;
                break;
            default:
                this.formato = "mp3";
        }
    }

    public String getTitulo() {
        return titulo;
    }

    public String getFormato() {
        return formato;
    }

    public int getDuracion() {
        return duracion;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Titulo: ").append(titulo)
                .append(" Formato: ").append(formato)
                .append(" Duracion: ").append(duracion);
        return sb.toString();
    }

    public boolean equals(Multimedia otroM) {
        return titulo.equals(otroM.titulo)
                && formato.equals(otroM.formato)
                && duracion == otroM.duracion;
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(!(o instanceof Multimedia)){
            return false;
        }
        return this.equals((Multimedia)o);
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.titulo);
        hash = 89 * hash + Objects.hashCode(this.formato);
        hash = 89 * hash + this.duracion;
        return hash;
    }

}
