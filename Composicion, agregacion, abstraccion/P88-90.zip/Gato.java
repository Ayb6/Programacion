
public class Gato extends Mamifero {

    public enum Pelaje {
        CORTO, LARGO, SEMILARGO;
        
        @Override
        public String toString(){
            switch(this){
                case CORTO:
                    return "corto";
                case LARGO:
                    return "largo";
                case SEMILARGO:
                    return "semilargo";
                default:
                    return "";
            }
        }
    }

    private Pelaje pelaje;

    public Gato(int numPatas, int mediaDeVida) {
        super(numPatas, mediaDeVida);
        pelaje = Pelaje.CORTO;
    }

    @Override
    public String comunicarse() {
        return "Miau miau";
    }

    @Override
    public void dormir() {
        System.out.println("Suele dormir 15 horas.");
    }

    public void cazar() {
        System.out.println("Mi gato de " + getNumPatas() + " patas esta cazando");
    }

    public Pelaje getPelaje() {
        return pelaje;
    }

    public void setPelaje(Pelaje pelaje) {
        this.pelaje = pelaje;
    }

    @Override
    public String toString() {

        return "Gato de pelaje " + pelaje.toString()
                + " con " + super.getNumPatas() + " patas y "
                + super.getMediaDeVida() + " media de vida.";
    }

}
